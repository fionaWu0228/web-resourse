<?php
header('Content-Type: text/html;charset=UTF-8');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>IME爱我</title>
    <link rel="stylesheet" href="css/common.css">
    <link rel="stylesheet" href="css/duitang.css">
    <link rel="stylesheet" href="css/animate.css">
</head>
<body>
    <header id="top">
        <div id="header">
					<div class="header_left">
						<a href="http://127.0.0.1:8080/duitang/" id="dt_logo"></a>
						<div id="sort">
							<a class="header_sort" href="#">分类</a>
							<div class="header_content">
								<ul class="nav_left">
									<li><a href="#">首页</a></li>
									<li><a href="#">热门</a></li>
									<li><a href="#">附近</a></li>
								</ul>
								<ul class="nav_right">
									<li><a href="#">家居生活</a></li>
									<li><a href="#">美食菜谱</a></li>
									<li><a href="#">美妆造型</a></li>
									<li><a href="#">美容护肤</a></li>
									<li><a href="#">生活百科</a></li>
									<li><a href="#">搞笑萌宠</a></li>
									<li><a href="#">时尚搭配</a></li>
									<li><a href="#">手工DIY</a></li>
									<li><a href="#">绘画插画</a></li>
									<li><a href="#">动漫漫画</a></li>
									<li><a href="#">文字句子</a></li>
									<li><a href="#">人文艺术</a></li>
								</ul>
							</div>
						</div>
						<div id="header_search">
							<form action="search_show.php" target="_blank">
								<input id="search" name="kw" type="text" placeholder="搜索感兴趣的内容">
								<button type="submit" id="submit"></button>
							</form>
							<ul class="img_list">

							</ul>
						</div>
					</div>
					<div class="header_right">
						<div class="phone">
							<span class="icon"></span>
							<a href="">手机版</a>
						</div>
						<b class="vline"></b>
						<div class="login">
							<a>登录</a>
						</div>
						<b class="vline"></b>
						<div class="register">
							<a href="ime_register.html" target="_blank">注册</a>
						</div>
						<b class="vline"></b>
						<div class="news">
							<a href="">堆糖生活家</a>
							<span>new</span>
						</div>
						<b class="vline"></b>
					</div>
				</div>
				<div class="clear"></div>
    </header>
    <div id="main">
			<div class="main_content">
				<div class="content_top">
					<div class="content_top_left">
						<div id="allswapImg">
							<div class="swapImg"><img src="img/banner/1.jpg" /></div>
						</div>
						<a class="btnLeft"></a>
						<a class="btnRight"></a>
						<div id="tabs">
							<div class="tab bg">1</div>
							<div class="tab">2</div>
							<div class="tab">3</div>
							<div class="tab">4</div>
							<div class="tab">5</div>
						</div>
					</div>
					<div class="content_top_right">
						<div class="hot">
							<div class="topic">社区热点</div>
							<div class="hot-line"></div>
							<ul class="hot-topic">							            
								<li><a href="#">秋天</a></li>
								<li>|</li>
								<li><a href="#">把生活过成一首诗</a></li>
								<li>|</li>
								<li><a href="#">手帐</a></li>
								<li>|</li>
								<li><a href="#">记下时间走过的路</a></li>
								<li>|</li>
								<li><a href="#">摄影</a></li>
								<li>|</li>
								<li><a href="#">家居</a></li>
								<li>|</li>
								<li><a href="#">原创</a></li>
							</ul>
							<div class="hot-active  animated bounce">
								<a href="#">有趣的旅行照</a>
								<a class="label-active" href="#">活动</a>
							</div>
							<div class="hot-jingxuan  animated bounce">
								<a href="#">『人气连衣裙精选』大合集</a>
								<a class="label-jingxuan" href="#">精选</a>
							</div>
							<div class="hot-gongju animated bounce">
								收图小助手：堆糖收集工具
							</div>
						</div>
						<a href="#" class="find">
							<img src="img/stastic/download.jpg">
						</a>
					</div>
				</div>
				<div class="content-line"></div>
				<div class="zjjx">
					<a href="#">往期回顾 &gt;</a>
					<p>专辑精选</p>
					<div class="img-zjjx">
						<div class="img-1">
							<img src="img/Collection/zjjx-1.jpg">
						</div>
						<div class="section-zjjx">
							<a href="#"><h4>画出你的衣柜</h4></a>
							<p>61张图片 · 1203人收藏</p>
							<p>by <a href="#">刘丹paper</a></p>
						</div>
						<div class="bottom-a"></div>
						<div class="bottom-b"></div>
					</div>
					<div class="img-zjjx">
						<div class="img-2">
							<img src="img/Collection/zjjx-2.jpg">
						</div>
						<div class="section-zjjx">
							<a href="#"><h4>猪猪の护肤好物</h4></a>
							<p>18张图片 · 2008人收藏</p>
							<p>by <a href="#">Avry猪猪君</a></p>
						</div>
						<div class="bottom-a"></div>
						<div class="bottom-b"></div>
					</div>
					<div class="img-zjjx">
						<div class="img-3">
							<img src="img/Collection/zjjx-3.jpg">
						</div>
						<div class="section-zjjx">
							<a href="#"><h4>出游这样穿，拍照也能美美的</h4></a>
							<p>89张图片 · 2332人收藏</p>
							<p>by <a href="#">baozi</a></p>
						</div>
						<div class="bottom-a"></div>
						<div class="bottom-b"></div>
					</div>
					<div class="img-zjjx">
						<div class="img-4">
							<img src="img/Collection/zjjx-4.jpg">
						</div>
						<div class="section-zjjx">
							<a href="#"><h4>有条有理，条纹控横竖都是范儿</h4></a>
							<p>78张图片 · 2128人收藏</p>
							<p>by <a href="#">郑南音</a></p>
						</div>
						<div class="bottom-a"></div>
						<div class="bottom-b"></div>
					</div>
					<div class="last img-zjjx">
						<div class="img-5">
							<img src="img/Collection/zjjx-5.jpg">
						</div>
						<div class="section-zjjx">
							<a href="#"><h4>简单卫衣显青春</h4></a>
							<p>79张图片 · 1392人收藏</p>
							<p>by <a href="#">夏茵</a></p>
						</div>
						<div class="bottom-a"></div>
						<div class="bottom-b"></div>
					</div>
				</div>
				<div class="content-line"></div>
				<div class="dptj">
					<ul class="dptj-buy">
						<li>良品购：</li>
						<li><a href="#">全部上衣</a></li>
						<li>|</li>
						<li><a href="#">上衣</a></li>
						<li>|</li>
						<li><a href="#">裙裤</a></li>
						<li>|</li>
						<li><a href="#">配饰</a></li>
						<li>|</li>
						<li><a href="#">鞋子</a></li>
						<li>|</li>
						<li><a href="#">包袋</a></li>
						<li>|</li>
						<li><a href="#">日杂</a></li>
					</ul>
					<p>单品推荐</p>
					<div class="img-dptj">
						<div class="img-1">
							<img src="img/recommand/dptj-1.jpg">
						</div>
						<div class="section-dptj">
							<p><a href="#">单鞋</a></p>
							<a href="#">良品购</a>
							<span>18733人正在逛</span>						
						</div>
						<div class="bottom-a"></div>
						<div class="bottom-b"></div>
					</div>
					<div class="img-dptj">
						<div class="img-2">
							<img src="img/recommand/dptj-2.jpg">
						</div>
						<div class="section-dptj">
							<p><a href="#">发饰</a></p>
							<a href="#">良品购</a>
							<span>18372人正在逛</span>						
						</div>
						<div class="bottom-a"></div>
						<div class="bottom-b"></div>
					</div>
					<div class="img-dptj">
						<div class="img-3">
							<img src="img/recommand/dptj-3.jpg">
						</div>
						<div class="section-dptj">
							<p><a href="#">裙子</a></p>
							<a href="#">良品购</a>
							<span>18726人正在逛</span>						
						</div>
						<div class="bottom-a"></div>
						<div class="bottom-b"></div>
					</div>
					<div class="img-dptj">
						<div class="img-4">
							<img src="img/recommand/dptj-4.jpg">
						</div>
						<div class="section-dptj">
							<p><a href="#">卫衣</a></p>
							<a href="#">良品购</a>
							<span>18574人正在逛</span>						
						</div>
						<div class="bottom-a"></div>
						<div class="bottom-b"></div>
					</div>
					<div class="img-dptj">
						<div class="img-5">
							<img src="img/recommand/dptj-5.jpg">
						</div>
						<div class="section-dptj">
							<p><a href="#">玩具</a></p>
							<a href="#">良品购</a>
							<span>18466人正在逛</span>						
						</div>
						<div class="bottom-a"></div>
						<div class="bottom-b"></div>
					</div>
				</div>
				<div class="content-line"></div>
				<div class="drtj">
					<a href="#">更多达人 &gt;</a>
					<p>达人推荐</p>
					<div class="img-drtj">
						<div class="img-1">
							<img class="cover" src="img/drtj/cover/1.jpg">
							<img class="peo" src="img/drtj/peo/1.jpg">
						</div>
						<div class="section-drtj">
							<p><a href="#">铁皮猫儿</a></p>
							<p>☆ 9127</p>
							<p>擅长领域：<b>园艺</b></p>
						</div>
						<div class="bottom-a"></div>
						<div class="bottom-b"></div>
					</div>
					<div class="img-drtj">
						<div class="img-2">
							<img class="cover" src="img/drtj/cover/2.jpg">
							<img class="peo" src="img/drtj/peo/2.jpg">
						</div>
						<div class="section-drtj">
							<p><a href="#">Leo摄影师</a></p>
							<p>☆ 7744</p>
							<p>擅长领域：<b>摄影</b></p>
						</div>
						<div class="bottom-a"></div>
						<div class="bottom-b"></div>
					</div>
					<div class="img-drtj">
						<div class="img-3">
							<img class="cover" src="img/drtj/cover/3.jpg">
							<img class="peo" src="img/drtj/peo/3.jpg">
						</div>
						<div class="section-drtj">
							<p><a href="#">OK酱</a></p>
							<p>☆ 9847</p>
							<p>擅长领域：<b>插画</b></p>
						</div>
						<div class="bottom-a"></div>
						<div class="bottom-b"></div>
					</div>
					<div class="img-drtj">
						<div class="img-4">
							<img class="cover" src="img/drtj/cover/4.jpg">
							<img class="peo" src="img/drtj/peo/4.jpg">
						</div>
						<div class="section-drtj">
							<p><a href="#">敲钟人伽西莫多</a></p>
							<p>☆ 324749</p>
							<p>擅长领域：<b>壁纸</b></p>
						</div>
						<div class="bottom-a"></div>
						<div class="bottom-b"></div>
					</div>
					<div class="img-drtj">
						<div class="img-5">
							<img class="cover" src="img/drtj/cover/5.jpg">
							<img class="peo" src="img/drtj/peo/5.jpg">
						</div>
						<div class="section-drtj">
							<p><a href="#">瓜小西xalayo</a></p>
							<p>☆ 6324</p>
							<p>擅长领域：<b>Q版 手工</b></p>
						</div>
						<div class="bottom-a"></div>
						<div class="bottom-b"></div>
					</div>
				</div>
				<div class="content-line"></div>
				<div class="masonry">
					<p>大家正在逛</p>
					<div class="zzg">

					</div>
					<a href="#" class="more">浏览更多 &gt;</a>
					<div class="blank"></div>
				</div>
			</div>
		</div>
    <footer id="footer">

		</footer>

		<!--模态登录对话框-->
		<div class="modal" id="modal-login">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="close">&times;</div>
					<h4>用户登录</h4>
					<p class="alert">
						请在此处输入您的注册信息。
					</p>
					<form id="login-form">
						<input type="text" placeholder="请输入登录用户名" id="uname">
						<input type="password" placeholder="请输入登录密码" id="upwd">
						<div id="bt-login">登录</div>
					</form>
				</div>
			</div>
		</div>
		<script src="js/jquery-1.11.3.js"></script>
		<script src="js/masonry.pkgd.js"></script>
		<script src="js/ime.js"></script>
</body>
</html>