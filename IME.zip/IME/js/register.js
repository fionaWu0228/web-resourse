//注册
var user=document.getElementById("user");
var pwd=document.getElementById("pwd");
var email=document.getElementById("email");
var age=document.getElementById("age");
var date=document.getElementById("date");
user.onfocus=function(){
    var b=this.nextElementSibling;
    b.innerHTML="请输入8至16位的英文或数字";
    b.style.background="#555";
}
user.onblur=function(){
    var b=this.nextElementSibling;
    if(this.validity.valueMissing){
        b.innerHTML="用户名不能为空";
        b.style.background="#e4393c";
    }else if(this.validity.patternMismatch){
        b.innerHTML="用户名输入格式错误";
        b.style.backgroundColor="#e4393c";
    }else{
        b.innerHTML="用户名正确";
        b.style.backgroundColor="#5cb85c";
    }
}
pwd.onfocus=function(){
    var b=this.nextElementSibling;
    b.innerHTML="请输入6至12位的数字";
    b.style.background="#555";
}
pwd.onblur=function(){
    var b=this.nextElementSibling;
    if(this.validity.valueMissing){
        b.innerHTML="用户名不能为空";
        b.style.background="#e4393c";
    }else if(this.validity.patternMismatch){
        b.innerHTML="密码输入格式错误";
        b.style.backgroundColor="#e4393c";
    }else{
        b.innerHTML="密码正确";
        b.style.backgroundColor="#5cb85c";
    }
}
email.onfocus=function(){
    var b=this.nextElementSibling;
    b.innerHTML="请输入你的电子邮件地址";
    b.style.background="#555";
}
email.onblur=function(){
    var b=this.nextElementSibling;
    if(this.validity.valueMissing){
        b.innerHTML="电子邮件不能为空";
        b.style.background="#e4393c";
    }else if(this.validity.typeMismatch){
        b.innerHTML="电子邮件输入格式错误";
        b.style.backgroundColor="#e4393c";
    }else{
        b.innerHTML="电子邮件正确";
        b.style.backgroundColor="#5cb85c";
    }
};
age.onfocus=function(){
    var b=this.nextElementSibling;
    b.innerHTML="请输入你的年龄";
    b.style.background="#555";
};
age.onblur=function(){
    var b=this.nextElementSibling;
    if(this.validity.valueMissing){
        b.innerHTML="年龄不能为空";
        b.style.background="#e4393c";
    }else if(this.validity.rangeUnderflow){
        b.innerHTML="年龄不能小于18!";
        b.style.backgroundColor="#e4393c";
    }else if(this.validity.rangeOverflow){
        b.innerHTML="年龄不能大于50!";
        b.style.backgroundColor="#e4393c";
    }else{
        b.innerHTML="年龄正确!";
        b.style.backgroundColor="#5cb85c";
    }
}

$('.btn_register').click(function(){
    var rname = $('#user').val();
    var rpwd = $('#pwd').val();
    console.log(rname+":"+rpwd);
    //$.ajax  $.post
    if(user.validity.valid&&user.validity.valid){
        $.post('data/ime_register.php', {uname:rname,upwd:rpwd}, function(obj){
        });
        alert('注册成功！');
    }
});
