$(function(){
    //加载瀑布流
    
        $('.zzg').masonry({
            itemSelector: '.box',
            columnWidth: 224,
            gutter: 20,  //槽宽
            transitionDuration: '1s',  //重设位置动画持续时间
        });

    //加载页头
    // $('#header').load('data/header.php');
    //加载页尾
    $('#footer').load('data/footer.php');

});


