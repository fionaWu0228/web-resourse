$(function(){
    //加载瀑布流
    $.getJSON('data/ime_zzg.php',function(list){
        // console.log('开始处理响应数据');
        var html = '';
        $.each(list, function(i,img){
            html += `
			<div class="box">
				<img src="${img.src}"/>
				<div class="zzg-section">
					<p>${img.text}</p>
					<div class="d">
						<span class="sc">${img.shoucang}</span>
						<span class="zan"></span>${img.zan}
					</div>
					<div class="u">
						<img src="${img.thumb}">
						<a href="#">${img.uname}</a>
					</div>
				</div>
				<div class="bottom-a"></div>
				<div class="bottom-b"></div>
			</div>
        `;
        });
        $('.zzg').html(html);
        $('.zzg').masonry({
            itemSelector: '.box',
            columnWidth: 224,
            gutter: 20,  //槽宽
            transitionDuration: '1s',  //重设位置动画持续时间
        });
    })
    //加载页头
    $('#header').load('data/header.php');
    //加载页尾
    $('#footer').load('data/footer.php');

});


