$(function(){
	//加载页头
	//$('#header').load('data/header.php');
	$('#footer').load('data/footer.php');
});

$(function(){

	//加载瀑布流
	$.getJSON('data/ime_zzg.php',function(list){
		// console.log('开始处理响应数据');
		var html = '';
		$.each(list, function(i,img){
			html += `
			<div class="box">
				<img src="${img.src}"/>
				<div class="zzg-section">
					<p>${img.text}</p>
					<div class="d">
						<span class="sc">${img.shoucang}</span>
						<span class="zan"></span>${img.zan}
					</div>
					<div class="u">
						<img src="${img.thumb}">
						<a href="#">${img.uname}</a>
					</div>
				</div>
				<div class="bottom-a"></div>
				<div class="bottom-b"></div>
			</div>
        `;
		});
		$('.zzg').html(html);
		$('.zzg').masonry({
			itemSelector: '.box',
			columnWidth: 224,
			gutter: 20,  //槽宽
			transitionDuration: '1s',  //重设位置动画持续时间
		});


	});
	//加载广告

	$.getJSON('data/ime_banner.php',function(list){
		// console.log('开始处理响应数据');
		var banner = '';
		$.each(list, function(i,img){
			banner += `
				<div class="swapImg"><img src="${img.src}" /></div>
			`;
		});
		$('#allswapImg').html(banner);
	});

	//加载页尾


});


//广告轮播
var i = 0;//全局变量
//定义一个变量用来获取轮播的过程
var time;
$(function () {
	//1.页面加载后,找到Class等于swapImg的第一个对象，让它显示，它的兄弟元素隐藏
	$(".swapImg").eq(0).show().siblings().hide();
	showTime();
	//当鼠标放到下标上显示该图片，鼠标移走继续轮播
	$(".tab").hover(
		function ()
		{
			//获取到当前鼠标所在的下标的索引
			i = $(this).index();
			show();
			//鼠标放上去之后，怎么停止呢？获取到变量的过程，清除轮播，把变量传进去
			clearInterval(time);
		}, function ()
		{
			showTime();
		});

	//要求四，当我点击左右切换
	$(".btnLeft").click(function ()
	{
		//1.点击之前要停止轮播
		clearInterval(time);
		//点了之后，-1
		if (i == 0)
		{
			i =5;
		}
		i--;
		show();
		showTime();
	});
	$(".btnRight").click(function () {
		//1.点击之前要停止轮播
		clearInterval(time);
		//点了之后，-1
		if (i == 4) {
			i = -1;
		}
		i++;
		show();
		showTime();
	});

});

function show() {
	$(".swapImg").eq(i).fadeIn(300).siblings().fadeOut();
	$(".tab").eq(i).addClass("bg").siblings().removeClass("bg");
}

function showTime() {
	time = setInterval(function () {
		i++;
		if (i == 5) {
			i = 0;
		}
		show();
	}, 3000);
}

$('#sort').on('mouseover',function(){
	$('.header_content').show();
});
$('#search').on('keyup',function () {
	$('.img_list').show();
	var k = this.value;  //获取输入框的当前值
	console.log(k);
	if(!k){
		$('.img_list').hide();
		return;
	}
	$.get('data/search.php',{kw:k},function (txt) {
		$('.img_list').html(txt);
	});
});
$('.header_content').on('mouseout',function(){
	$('.header_content').hide();
});
$('.login>a').click(function () {
	$('.modal').show();
});
$('.close').click(function () {
	$('.modal').fadeOut();
});
var loginName = null; //当前登录的用户名
$('#bt-login').click(function(){
	var iname = $('#uname').val();
	var ipwd = $('#upwd').val();
	console.log(iname+":"+ipwd);
	//$.ajax  $.post
	$.post('data/ime_login.php', {uname:iname,upwd:ipwd}, function(obj){
		console.log('开始处理登录验证结果');
		//console.log(arguments);
		if(obj.code===1000){ //验证成功
			$('.modal').fadeOut(); //摸态框淡出
			loginName = $('[id="uname"]').val();
			$('.login').html('欢迎回来：<a href="usercenter.html" target="-_blank" href="#">'+loginName+'</a>');
		}else {
			$('.modal .alert').html(obj.msg);
		}
	});
});