<?php

header('Content-Type: application/json;charset=UTF-8');
$conn = mysqli_connect('127.0.0.1', 'root', '', 'ime', 3306);
$sql = "SET NAMES UTF8";
mysqli_query($conn,$sql);
$sql = "SELECT * FROM ime_img";
$result = mysqli_query($conn,$sql);
$arr = [];
while(($img=mysqli_fetch_assoc($result))!=null){
	//echo json_encode($car);//array => json string
	$arr[] = $img;
}

echo json_encode($arr);