<?php
	header('Content-Type:application/json');
	$uname=$_REQUEST['uname'];
	$upwd=$_REQUEST['upwd'];
	$conn=mysqli_connect('127.0.0.1','root','','ime',3306);
	$sql="SET NAMES UTF8";
	mysqli_query($conn,$sql);
	$sql="INSERT INTO ime_user VALUES(NULL,'$uname','$upwd')";
	$result=mysqli_query($conn,$sql);
	if($result){
		echo'succ';
	}else{
		echo'err';
	}