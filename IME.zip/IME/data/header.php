<?php
    header('Content-Type: text/html;charset=UTF-8');
?>
     <div class="header_left">
       <a href="http://127.0.0.1:8080/duitang/" id="dt_logo"></a>
       <div id="sort">
	        <a class="header_sort" href="#">分类</a>
			<div class="header_content">
			<ul class="nav_left">
				<li><a href="#">首页</a></li>
				<li><a href="#">热门</a></li>
				<li><a href="#">附近</a></li>
			</ul>
			<ul class="nav_right">
				<li><a href="#">家居生活</a></li>
				<li><a href="#">美食菜谱</a></li>
				<li><a href="#">美妆造型</a></li>
				<li><a href="#">美容护肤</a></li>
				<li><a href="#">生活百科</a></li>
				<li><a href="#">搞笑萌宠</a></li>
				<li><a href="#">时尚搭配</a></li>
				<li><a href="#">手工DIY</a></li>
				<li><a href="#">绘画插画</a></li>
				<li><a href="#">动漫漫画</a></li>
				<li><a href="#">文字句子</a></li>
				<li><a href="#">人文艺术</a></li>
			</ul>
		</div>
	   </div>
	   <div id="header_search">
			<form action="#">
                <input name="search_kd" type="text" placeholder="搜索感兴趣的内容">
				<button id="submit" type="submit"></button>
			</form>
			</div>
       </div>
       <div class="header_right">
			<div class="phone">
				<span class="icon"></span>
				<a href="">手机版</a>
			</div>
			<b class="vline"></b>
			<div class="login">
				<a>登录</a>
			</div>
			<b class="vline"></b>
			<div class="register">
				<a href="ime_register.html" target="_blank">注册</a>
			</div>
			<b class="vline"></b>
			<div class="news">
				<a href="">堆糖生活家</a>
				<span>new</span>
			</div>
			<b class="vline"></b>
	   </div>