<?php
header('Content-Type: text/html;charset=UTF-8');

$kw = $_REQUEST['kw'];

$conn = mysqli_connect('127.0.0.1', 'root', '', 'ime', 3306);

$sql = "SET NAMES UTF8";
mysqli_query($conn,$sql);
$sql = "SELECT * FROM ime_img WHERE text LIKE '%$kw%'";
$result = mysqli_query($conn,$sql);

if(!$result){
	echo "<li>SQL语法错误：$sql</li>";
}else {
	$html = "";
	while(($row=mysqli_fetch_assoc($result))!==null){
		$html .= "<li><a href='#'>$row[text]</a></li>";
	}
	echo $html;
}