<?php
    header('Content-Type: text/html;charset=UTF-8');
?>
<div class="main_foot">
	<div class="col">
	    <p>关于我们</p>
	    <ul>
	        <li><a href="#">关于我们</a></li>
	        <li><a href="#">帮助中心</a></li>
		    <li><a href="#">加入我们</a></li>
			<li><a href="#">联系我们</a></li>
			<li><a href="#">收集工具</a></li>
			<li><a href="#">标签集</a></li>
			<li><a href="#">商务合作</a></li>
			<li><a href="#">免责声明</a></li>
		</ul>
	</div>
	<div class="col">
	    <p>手机应用</p>
	    <ul>
			<li><a href="#">IME客户端</a></li>
			<li><a href="#">爱疯了壁纸</a></li>
			<li><a href="#">IME良品购</a></li>
		</ul>
	</div>
	<div class="col">
		<img class="ewm" src="img/stastic/qrcode.png">
		<p class="down">扫描二维码下载堆糖手机客户端</p>
	</div>
	<div class="col">
		<p>关注我们</p>
		<ul>
			<li><a href="#">新浪微博</a></li>
			<li><a href="#">微信</a></li>
			<li><a href="#">腾讯微博</a></li>
			<li><a href="#">qq空间</a></li>
			<li><a href="#">人人网</a></li>
			<li><a href="#">豆瓣</a></li>
		</ul>
	</div>
	<div class="col">
		<p>友情链接</p>
		<ul>
			<li><a href="#">美食美酒网</a></li>
			<li><a href="#">东方女性网</a></li>
			<li><a href="#">传导体招聘</a></li>
			<li><a href="#">LADYMAX时尚</a></li>
			<li><a href="#">爱物网</a></li>
			<li><a href="#">携程攻略</a></li>
			<li><a href="#"></a>肉丁网</li>
			<li><a href="#">更多..</a></li>
		</ul>
	</div>
</div>
<div class="bottom_foot">
	<span>©2016 IME.com 版权所有。浙ICP备10068096号-1</span>
</div>