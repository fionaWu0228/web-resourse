SET NAMES UTF8;
DROP DATABASE IF EXISTS ime;
CREATE DATABASE ime CHARSET=UTF8;
USE ime;

CREATE TABLE ime_user(
  uid INT PRIMARY KEY AUTO_INCREMENT, 
  uname VARCHAR(32),
  upwd VARCHAR(32)
);
CREATE TABLE ime_img(
  mid INT PRIMARY KEY AUTO_INCREMENT,
  src VARCHAR(32),
  text VARCHAR(64),
  shoucang INT,
  zan INT,
  thumb VARCHAR(32),
  uname VARCHAR(32)
);
CREATE TABLE ime_banner(
  mid INT PRIMARY KEY AUTO_INCREMENT,
  src VARCHAR(32),
  text VARCHAR(64),
  href VARCHAR(64)
);
INSERT INTO ime_user VALUES
('1','admin','123456'),
('2','wuyanjuan','123456');

INSERT INTO ime_img VALUES
(NULL,'img/zzg/1.jpg','条纹闺蜜装',48,2,'img/stastic/thumb/1.jpg','有北不受'),
(NULL,'img/zzg/2.jpg','#homecoming @polyvore @polyvore-editorial #polyvore #polyvoreeditorials #polyvoreeditorial #PolyvoreMostStylish #PolyvoreTrendReport',38,6,'img/stastic/thumb/2.jpg','-瑶小瑶'),
(NULL,'img/zzg/3.jpg','阴阳师#酒吞童子',18,1,'img/stastic/thumb/3.jpg','我偏独坐第一香'),
(NULL,'img/zzg/4.jpg','阴阳师#大天狗',40,3,'img/stastic/thumb/4.jpg','孤独的一颗心'),
(NULL,'img/zzg/5.jpg','阴阳师',180,67,'img/stastic/thumb/5.jpg','關山千裏'),
(NULL,'img/zzg/6.jpg','Alexander McQueen 2017春夏系列时装秀',20,9,'img/stastic/thumb/6.jpg','lovieeek'),
(NULL,'img/zzg/7.jpg','Jenny Packham 2015 春夏高级成衣这一季设计师的灵感缪斯源自玛丽莲·梦露(Marilyn Monroe)，优雅妩媚的迷人魅力再次被身穿柔和色彩并有着修身线条的长裙模特们演绎呈现，虽然没有那条经典的小白裙，然而一条条拥有细节精髓设计的美裙同样可以迷惑你的心～',620,429,'img/stastic/thumb/7.jpg','Nyx-Ghost'),
(NULL,'img/zzg/8.jpg','阴阳师',110,54,'img/stastic/thumb/8.jpg','神算Zzz'),
(NULL,'img/zzg/9.jpg','Christian Dior 2017春夏系列时装秀',90,39,'img/stastic/thumb/9.jpg','-阿舍-'),
(NULL,'img/zzg/10.jpg','毛毛鞋',67,34,'img/stastic/thumb/10.jpg','半月蒼竹');

INSERT INTO ime_banner VALUES
(NULL,'img/banner/1.jpg','第一张图片','#'),
(NULL,'img/banner/2.jpg','第二张图片','#'),
(NULL,'img/banner/3.jpg','第三张图片','#'),
(NULL,'img/banner/4.jpg','第四张图片','#'),
(NULL,'img/banner/5.jpg','第五张图片','#');
