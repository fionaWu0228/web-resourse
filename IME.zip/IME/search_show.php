<?php
header('Content-Type: text/html;charset=UTF-8');

$kw = $_REQUEST['kw'];

$conn = mysqli_connect('127.0.0.1', 'root', '', 'ime', 3306);

$sql = "SET NAMES UTF8";
mysqli_query($conn,$sql);
$sql = "SELECT * FROM ime_img WHERE text LIKE '%$kw%'";
$result = mysqli_query($conn,$sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Title</title>
  <link rel="stylesheet" href="css/common.css">
  <link rel="stylesheet" href="css/duitang.css">
</head>
<body>
  <header id="top">
    <div id="header">
    </div>
    <div class="clear"></div>
  </header>
  <div id="main">
    <div class="masonry">
      <p>搜索关键字<?php echo "'$kw'" ?>的结果如下：</p>
      <div class="zzg">
           <?php while(($img=mysqli_fetch_assoc($result))!=null){
           	//echo json_encode($car);//array => json string
           	    echo "<div class='box'>";
           	    echo "<img src='$img[src]'>";
           	    echo "<div class='zzg-section'>";
           	    echo "<p>$img[text]</p>";
           	    echo "<div class='d'>";
           	    echo "<span class='sc'>$img[shoucang]</span>";
           	    echo "<span class='zan'></span>$img[zan]";
           	    echo "</div>";
           	    echo "<div class='u'>";
           	    echo "<img src='$img[thumb]'>";
           	    echo "<a href='#'>$img[uname]</a>";

           	    echo "</div></div><div class='bottom-a'></div><div class='bottom-b'></div></div>";
           }
           ?>
      </div>
      <a href="#" class="more">浏览更多 &gt;</a>
      <div class="blank"></div>
    </div>
  </div>
  <footer id="footer">

  </footer>
  <script src="js/jquery-1.11.3.js"></script>
  <script src="js/masonry.pkgd.js"></script>
  <script src="js/search.js"></script>
</body>
</html>